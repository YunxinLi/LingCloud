# ofa模型在多个数据集上的zero-shot测试

# 预训练的第三阶段，再额外训练一个linear
# 第二阶段的预训练
# 需要加载第一阶段训练完成的textLinear，并将其冻结
import json
import pickle
import sys
import argparse
import os

from local_transformers.transformers.models.ofa import OFATokenizer, OFAConfig, OFAModel

os.environ['CUDA_VISIBLE_DEVICES'] = '4'
import clip
import torch
import random
import numpy as np
import torch.distributed as dist
from torch import nn
from torch.utils.data import DataLoader
from torch.optim import AdamW

# from local_transformers.transformers import GPT2Tokenizer
from transformers import GPT2Tokenizer

from local_transformers.transformers_new.models.blip_2 import Blip2ForConditionalGeneration
from local_transformers.transformers_new import DataCollatorForLanguageModeling, PreTrainedTokenizer, Blip2Processor
from Data.mapping_dataset import llm_extra_dataset, llm_extra_dataset_caption, llm_extra_dataset_ddp, \
    llm_extra_dataset_vqa, llm_extra_dataset_predict
from Data.dataset_other import blip2_dataset_predict
from modeling.modeling_mapping import promot_model_stage2, promot_model_stage2_less

from utils.logger import setup_logger
from progressbar import ProgressBar
from utils.misc import (mkdir, set_seed,
                        load_from_yaml_file, find_file_path_in_yaml)
from utils.trie import Trie
from apex.parallel import DistributedDataParallel
from apex.parallel import convert_syncbn_model
from apex import amp


# DEVICE = 0
# device = torch.device("cuda:{}".format(DEVICE))

def generate(args, dataloader, model, tokenizer):
    model.eval()
    pbar = ProgressBar(n_total=len(dataloader), desc='testing')
    outputs = []
    with torch.no_grad():
        for step, batch in enumerate(dataloader):
            inputs = batch["inputs"]
            a = 1
        #     input_ids = batch["input_ids"].cuda()
        #     attention_mask = batch["attention_mask"].cuda()
        #     images = batch["images"].cuda()
        #     image_id = batch["image_id"].cpu().numpy()
        #     img_feat = []
        #     id = batch['id'].cpu().numpy()
        #     for i in image_id:
        #         if args.predict_task == "pmr" or args.predict_task == "vcr":
        #             img_feat.append(clip_img_feat["val-" + str(i)])
        #         else:
        #             img_feat.append(clip_img_feat[str(i)])
        #     img_feat = torch.stack(img_feat).cuda().squeeze(dim=1)
        #
        #     text = ["! " * args.prompt_len] * input_ids.size(0)
        #
        #     if args.special_vqa:
        #         for idx in range(len(text)):
        #             caption = imgid2caption[image_id[idx]]
        #             text[idx] += caption
        #
        #
        #
        #     # generate_ids = model.generate(llm_text_input=input_ids, llm_attention_mask=attention_mask,
        #     #                               clip_img_input=img_feat, clip_text_input=clip_text_ids,
        #     #                               clip_attention_mask=clip_attention_mask, img_token_id=tokenizer.vocab_size,
        #     #                               task=args.predict_task)
        #
        #     output = tokenizer.batch_decode(generate_ids, skip_special_tokens=True, clean_up_tokenization_spaces=False)[
        #         0]
        #     if args.predict_task == "cc3m-caption":
        #         tmp = {"output": output}
        #     elif args.predict_task == "coco-caption":
        #         tmp = {"image_id": int(image_id), "caption":output}
        #     elif args.predict_task == "vqa":
        #         tmp = {"question_id": int(id), "answer": output}
        #     elif args.predict_task == "pmr" or args.predict_task == "vcr":
        #         # mapping = {"A":0,"B":1,"C":2,"D":3}
        #         # tmp = {"output": mapping[output[-2]]}
        #         tmp = {"output": output}
        #     outputs.append(tmp)
        #     pbar(step=step)
        #
        # if args.predict_task == "cc3m-caption":
        #     with open(args.cc3m_caption_result_file, "w") as f:
        #         for line in outputs:
        #             f.write(json.dumps(line, ensure_ascii=False) + "\n")
        #             f.flush()
        # elif args.predict_task == "coco-caption":
        #     with open(args.coco_caption_result_file, "w") as f:
        #         json.dump(outputs, f)
        # elif args.predict_task == "vqa":
        #     with open(args.vqa_result_file, "w") as f:
        #         json.dump(outputs, f)
        # elif args.predict_task == "pmr":
        #     with open(args.pmr_result_file, "w") as f:
        #         json.dump(outputs, f)



def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--eval_data_cc3m",
                        # default="dataset/CC3M/CC3M_val_3000.json",
                        default="dataset/VQA2/caption/caption4vqa.json",
                        type=str)
    parser.add_argument("--eval_data_coco",
                        default="coco_data/coco-caption_val.json",
                        type=str)
    parser.add_argument("--vqa_data",
                        default="dataset/VQA2/val_vqav2_10000.json")
    parser.add_argument("--pmr_data",
                        default="dataset/PMR/val-ori_re.json")
    parser.add_argument("--vcr_data",
                        default="dataset/VCR/val_re.json")

    parser.add_argument("--seed", default=3407, type=int)
    parser.add_argument("--batch_size", default=1, type=int)
    parser.add_argument("--special_vqa", action="store_true")
    parser.add_argument("--prompt_type", default=0, type=int)
    parser.add_argument("--output_dir", default="output/tmp", type=str)


    parser.add_argument("--predict_task", default="cc3m-caption", type=str)

    parser.add_argument("--vqa_result_file", default="result/vqa/prompt_test/prompt2_epoch3_re.json", type=str)
    parser.add_argument("--pmr_result_file", default="result/pmr/opt-epoch1-new.json", type=str)
    parser.add_argument("--vcr_result_file", default="result/vcr/test.json", type=str)
    parser.add_argument("--cc3m_caption_result_file", default="dataset/VQA2/caption/caption-opt-stage2.json", type=str)
    parser.add_argument("--coco_caption_result_file", default="result/caption/coco2017/llama-stage2-less-epoch4.json", type=str)

    args = parser.parse_args()

    global logger

    mkdir(args.output_dir)
    seed = args.seed
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed(seed)

    logger = setup_logger("mvp_finetune_pmr", args.output_dir, 0)
    logger.warning("Device: %s, n_gpu: %s", torch.cuda.current_device(), torch.cuda.device_count())

    # -------------------------加载OPT-iml模型-----------------------

    ckpt_dir = "/data/share/Model/blip2/blip2-opt-2.7b/"
    processor = Blip2Processor.from_pretrained(ckpt_dir)
    model = Blip2ForConditionalGeneration.from_pretrained(ckpt_dir)


    if args.predict_task == "cc3m-caption":
        dataset = blip2_dataset_predict(args.eval_data_cc3m, processor)
    elif args.predict_task == "coco-caption":
        dataset = blip2_dataset_predict(args.eval_data_coco, processor)
    elif args.predict_task == "vqa":
        dataset = blip2_dataset_predict(args.vqa_data, processor, prompt_type=args.prompt_type)
    elif args.predict_task == "pmr":
        dataset = blip2_dataset_predict(args.pmr_data, processor, task=args.predict_task)
    elif args.predict_task == "vcr":
        dataset = blip2_dataset_predict(args.vcr_data, processor, task=args.predict_task)
    train_sampler = torch.utils.data.SequentialSampler(dataset)
    dataloader = torch.utils.data.DataLoader(dataset, batch_size=1, sampler=train_sampler)

    generate(args, dataloader, model, processor)


if __name__ == "__main__":
    main()
