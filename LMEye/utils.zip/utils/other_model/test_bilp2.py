# import torch
# from PIL import Image
# import torch
# from lavis.models import load_model_and_preprocess
# # setup device to use
# device = torch.device("cuda") if torch.cuda.is_available() else "cpu"
# # load sample image
# raw_image = Image.open("/data/share/dataset/ConceptualCaption3M/image_val/1000.jpg").convert("RGB")
#
# model, vis_processors, _ = load_model_and_preprocess(name="blip2_opt", model_type="caption_coco_opt2.7b", is_eval=True, device=device)
#
# image = vis_processors["eval"](raw_image).unsqueeze(0).to(device)
#
# model.generate({"image": image})

import torch
import requests
from PIL import Image
from local_transformers.transformers_new.models.blip_2 import Blip2Processor, Blip2ForConditionalGeneration

processor = Blip2Processor.from_pretrained("/data/share/Model/blip2/blip2-opt-2.7b/")
# model = Blip2ForConditionalGeneration.from_pretrained("/data/share/Model/blip2/blip2-opt-2.7b/")

img_url = '/data/cxy/ReasoningTask/dataset/PMR/images/lsmdc_0001_American_Beauty/0001_American_Beauty_00.02.48.867-00.02.55.904@2.jpg'
raw_image = Image.open(img_url).convert('RGB')
raw_image1 = Image.open(img_url).convert('RGB')

image = [raw_image, raw_image1]

question = "how many dogs are in the picture?"
inputs = processor(image, question, return_tensors="pt")

b = 1
# out = model.generate(**inputs)
# print(processor.decode(out[0], skip_special_tokens=True))