# ofa模型在多个数据集上的zero-shot测试

# 预训练的第三阶段，再额外训练一个linear
# 第二阶段的预训练
# 需要加载第一阶段训练完成的textLinear，并将其冻结
import json
import pickle
import sys
import argparse
import os

from local_transformers.transformers.models.ofa import OFATokenizer, OFAConfig, OFAModel

os.environ['CUDA_VISIBLE_DEVICES'] = '1'
import clip
import torch
import random
import numpy as np
import torch.distributed as dist
from torch import nn
from torch.utils.data import DataLoader
from torch.optim import AdamW

# from local_transformers.transformers import GPT2Tokenizer
from transformers import GPT2Tokenizer

from local_transformers.transformers_new import DataCollatorForLanguageModeling, PreTrainedTokenizer
from Data.mapping_dataset import llm_extra_dataset, llm_extra_dataset_caption, llm_extra_dataset_ddp, \
    llm_extra_dataset_vqa, llm_extra_dataset_predict
from modeling.modeling_mapping import promot_model_stage2, promot_model_stage2_less

from utils.logger import setup_logger
from progressbar import ProgressBar
from utils.misc import (mkdir, set_seed,
                        load_from_yaml_file, find_file_path_in_yaml)
from utils.trie import Trie
from apex.parallel import DistributedDataParallel
from apex.parallel import convert_syncbn_model
from apex import amp


# DEVICE = 0
# device = torch.device("cuda:{}".format(DEVICE))

def generate(args, dataloader, model, tokenizer):
    model.eval()
    pbar = ProgressBar(n_total=len(dataloader), desc='testing')
    outputs = []
    with torch.no_grad():
        for step, batch in enumerate(dataloader):
            input_ids = batch["input_ids"].cuda()
            attention_mask = batch["attention_mask"].cuda()
            images = batch["images"].cuda()
            image_id = batch["image_id"].cpu().numpy()
            img_feat = []
            id = batch['id'].cpu().numpy()
            for i in image_id:
                if args.predict_task == "pmr" or args.predict_task == "vcr":
                    img_feat.append(clip_img_feat["val-" + str(i)])
                else:
                    img_feat.append(clip_img_feat[str(i)])
            img_feat = torch.stack(img_feat).cuda().squeeze(dim=1)

            text = ["! " * args.prompt_len] * input_ids.size(0)

            if args.special_vqa:
                for idx in range(len(text)):
                    caption = imgid2caption[image_id[idx]]
                    text[idx] += caption

            clip_text = clip_tokenizer(text, max_length=77, padding=True, return_tensors="pt", truncation=True)
            clip_text_ids = clip_text["input_ids"].cuda()
            clip_attention_mask = clip_text["attention_mask"].cuda()

            generate_ids = model.generate(llm_text_input=input_ids, llm_attention_mask=attention_mask,
                                          clip_img_input=img_feat, clip_text_input=clip_text_ids,
                                          clip_attention_mask=clip_attention_mask, img_token_id=tokenizer.vocab_size,
                                          task=args.predict_task)

            output = tokenizer.batch_decode(generate_ids, skip_special_tokens=True, clean_up_tokenization_spaces=False)[
                0]
            if args.predict_task == "cc3m-caption":
                tmp = {"output": output}
            elif args.predict_task == "coco-caption":
                tmp = {"image_id": int(image_id), "caption":output}
            elif args.predict_task == "vqa":
                tmp = {"question_id": int(id), "answer": output}
            elif args.predict_task == "pmr" or args.predict_task == "vcr":
                # mapping = {"A":0,"B":1,"C":2,"D":3}
                # tmp = {"output": mapping[output[-2]]}
                tmp = {"output": output}
            outputs.append(tmp)
            pbar(step=step)

        if args.predict_task == "cc3m-caption":
            with open(args.cc3m_caption_result_file, "w") as f:
                for line in outputs:
                    f.write(json.dumps(line, ensure_ascii=False) + "\n")
                    f.flush()
        elif args.predict_task == "coco-caption":
            with open(args.coco_caption_result_file, "w") as f:
                json.dump(outputs, f)
        elif args.predict_task == "vqa":
            with open(args.vqa_result_file, "w") as f:
                json.dump(outputs, f)
        elif args.predict_task == "pmr":
            with open(args.pmr_result_file, "w") as f:
                json.dump(outputs, f)


def init(args):
    # 加载提前抽取好的clip图像特征和文本特征
    global clip_img_feat, clip_text_feat, imgid2caption
    if args.predict_task == "cc3m-caption":
        clip_img_feat = pickle.load(open("coco_data/img_feat/coco_img_large.pkl", "rb"))
        # clip_img_feat = pickle.load(open("dataset/CC3M/cc3m_img_val.pkl", "rb"))
        clip_text_feat = pickle.load(open("coco_data/id2text.pkl", "rb"))
    elif args.predict_task == "coco-caption":
        clip_img_feat = pickle.load(open("coco_data/img_feat/coco_img_large.pkl", "rb"))
    elif args.predict_task == "vqa":
        clip_img_feat = pickle.load(open("coco_data/img_feat/coco_img_large.pkl", "rb"))
        imgid2caption = pickle.load(open("dataset/VQA2/caption/imgid2caption.pkl", "rb"))
    elif args.predict_task == "pmr":
        clip_img_feat = pickle.load(open("dataset/PMR/img_feat_val.pkl", "rb"))
    elif args.predict_task == "vcr":
        clip_img_feat = pickle.load(open("dataset/VCR/img_feat_val.pkl", "rb"))



def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--eval_data_cc3m",
                        # default="dataset/CC3M/CC3M_val_3000.json",
                        default="dataset/VQA2/caption/caption4vqa.json",
                        type=str)
    parser.add_argument("--eval_data_coco",
                        default="coco_data/coco-caption_val.json",
                        type=str)
    parser.add_argument("--vqa_data",
                        default="dataset/VQA2/val_vqav2_10000.json")
    parser.add_argument("--pmr_data",
                        default="dataset/PMR/val-ori_re.json")
    parser.add_argument("--vcr_data",
                        default="dataset/VCR/val_re.json")

    parser.add_argument("--seed", default=3407, type=int)
    parser.add_argument("--batch_size", default=1, type=int)
    parser.add_argument("--special_vqa", action="store_true")
    parser.add_argument("--prompt_type", default=0, type=int)
    parser.add_argument("--output_dir", default="output/tmp", type=str)


    parser.add_argument("--predict_task", default="cc3m-caption", type=str)

    parser.add_argument("--vqa_result_file", default="result/vqa/prompt_test/prompt2_epoch3_re.json", type=str)
    parser.add_argument("--pmr_result_file", default="result/pmr/opt-epoch1-new.json", type=str)
    parser.add_argument("--vcr_result_file", default="result/vcr/test.json", type=str)
    parser.add_argument("--cc3m_caption_result_file", default="dataset/VQA2/caption/caption-opt-stage2.json", type=str)
    parser.add_argument("--coco_caption_result_file", default="result/caption/coco2017/llama-stage2-less-epoch4.json", type=str)

    args = parser.parse_args()

    global logger

    print("using language model {}".format(args.llm_model.upper()))
    print("doing task {}".format(args.predict_task.upper()))

    mkdir(args.output_dir)
    seed = args.seed
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed(seed)

    init(args)

    logger = setup_logger("mvp_finetune_pmr", args.output_dir, 0)
    logger.warning("Device: %s, n_gpu: %s", torch.cuda.current_device(), torch.cuda.device_count())

    # -------------------------加载OPT-iml模型-----------------------

    ckpt_dir = "./local_transformers/OFA-large/"
    tokenizer = OFATokenizer.from_pretrained(ckpt_dir)
    config = OFAConfig.from_pretrained(ckpt_dir + "config.json")
    model = OFAModel.from_pretrained(ckpt_dir, use_cache=False, config=config)


    if args.predict_task == "cc3m-caption":
        dataset = llm_extra_dataset_caption(args.eval_data_cc3m, tokenizer)
    elif args.predict_task == "coco-caption":
        dataset = llm_extra_dataset_caption(args.eval_data_coco, tokenizer)
    elif args.predict_task == "vqa":
        dataset = llm_extra_dataset_vqa(args.vqa_data, tokenizer, prompt_type=args.prompt_type)
    elif args.predict_task == "pmr":
        dataset = llm_extra_dataset_predict(args.pmr_data, tokenizer, task=args.predict_task)
    elif args.predict_task == "vcr":
        dataset = llm_extra_dataset_predict(args.vcr_data, tokenizer, task=args.predict_task)
    collate_fn = DataCollatorForLanguageModeling(tokenizer, mlm=False, return_tensors="pt")
    dataloader = DataLoader(dataset, drop_last=False, batch_size=1,
                            num_workers=0,
                            shuffle=False, collate_fn=collate_fn)

    generate(args, dataloader, model, tokenizer)


if __name__ == "__main__":
    main()
