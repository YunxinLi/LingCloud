# 抽取laion-400M数据集的图像特征

import json
import os
import clip
import torch
import pickle
import numpy as np
from torch.utils.data import Dataset
from tqdm import tqdm
from PIL import Image
from torch.utils.data import DataLoader
DEVICE = 0
device = torch.device("cuda:{}".format(DEVICE))



# COCO_train2014_000000
class ImageDatasetLaion(Dataset):
    def __init__(self, data, preprocess, image_path):
        self.data = data
        self.preprocess = preprocess
        self.image_path = image_path

    def __len__(self):
        return len(self.data)

    def __getitem__(self, i):
        example = self.data[i]
        image_path = os.path.join(self.image_path, example['image_id'] + ".jpg")
        image = Image.open(image_path).convert('RGB')

        image = preprocess(image).to(device)
        img_id = example["image_id"]
        return {"image_id":img_id,
                "image":image,}

    def gen_collate(self, inputs):
        image = [i['image'] for i in inputs]
        image_id = [i["image_id"] for i in inputs]
        image = torch.stack(image)

        return {"image_id":image_id,
                "image":image}

clip_model, preprocess = clip.load('ViT-L/14', jit=False, device=device)
clip.model.convert_weights(clip_model)

clip_model = clip_model.to(device)


if __name__ == "__main__":
    begin = 100
    end = 150
    base_image_path = "/data/share/datasets/Laion-400m/data/"
    base_extract_file_path = "/data/share/datasets/Laion-400m/data/caption/"
    base_output_path = "/data/share/datasets/Laion-400m/image_feat/"
    for i in range(begin, end):
        print("doing group {}".format(i))
        extract_file = os.path.join(base_extract_file_path, f"{i:03d}.json")
        image_path = os.path.join(base_image_path, f"{i:03d}")
        output_dir = os.path.join(base_output_path, f"{i:03d}")
        if not os.path.exists(output_dir):
            os.makedirs(output_dir)

        ex_data = json.load(open(extract_file, "r"))
        cc3m_dataset = ImageDatasetLaion(ex_data, preprocess, image_path)

        dataloader = DataLoader(cc3m_dataset, drop_last=False, batch_size=128,
                                num_workers=0,
                                shuffle=False, collate_fn=cc3m_dataset.gen_collate)

        with torch.no_grad():
            with tqdm(total=len(dataloader)) as pbar:
                clip_model.eval()
                for step, batch in enumerate(dataloader):
                    image = batch["image"]
                    image_id = batch["image_id"]
                    image_feats = clip_model.encode_image(image)
                    image_feats = image_feats.cpu().numpy()

                    for idx, img_id in enumerate(image_id):
                        image_feat = image_feats[idx]
                        numpy_file_name = os.path.join(output_dir, img_id + ".npy")
                        np.save(numpy_file_name, image_feat)
                    pbar.update(1)

