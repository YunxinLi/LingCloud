import json

import clip
import torch
import pickle
from torch.utils.data import Dataset
from tqdm import tqdm
from PIL import Image
from torch.utils.data import DataLoader
DEVICE = 4
device = torch.device("cuda:{}".format(DEVICE))



# COCO_train2014_000000
class ImageDatasetCC3M(Dataset):
    def __init__(self, data, preprocess):
        self.data = data
        self.preprocess = preprocess

    def __len__(self):
        return len(self.data)

    def __getitem__(self, i):
        example = self.data[i]
        img_fn = example['img_fn']
        image_path = "../../dataset/VCR/vcr1images/" + img_fn
        image = Image.open(image_path).convert('RGB')

        image = preprocess(image).to(device)
        img_id = example["image_id"]
        return {"image_id":img_id,
                "image":image,}

    def gen_collate(self, inputs):
        image = [i['image'] for i in inputs]
        image_id = [i["image_id"] for i in inputs]
        image = torch.stack(image)

        return {"image_id":image_id,
                "image":image}

clip_model, preprocess = clip.load('ViT-L/14', jit=False)
clip.model.convert_weights(clip_model)

clip_model = clip_model.to(device)

extract_file = "../../dataset/VCR/test_re.json"
output_file = "../../dataset/VCR/img_feat_test.pkl"

dict = {}
with open(extract_file, 'r') as file:
    lines = file.readlines()
    ex_data = [json.loads(line) for line in lines]

# for data in ex_data:
#     data["image_id"] = data["img_id"]

cc3m_dataset = ImageDatasetCC3M(ex_data, preprocess)
dataloader = DataLoader(cc3m_dataset, drop_last=False, batch_size=1,
                                num_workers=0,
                                shuffle=False, collate_fn=cc3m_dataset.gen_collate)

with torch.no_grad():
    with tqdm(total=len(dataloader)) as pbar:
        clip_model.eval()
        for step, batch in enumerate(dataloader):
            pbar.update(1)
            # -----------image-------------
            if batch['image_id'][0] in dict:
                continue
            else:
                image = batch["image"]
                image_feat = clip_model.encode_image(image)
                # image_feat = image_feat.squeeze(dim=1)  # 仅仅是为了保持一致性
                image_feat = image_feat.cpu()

                assert batch['image_id'][0] not in dict
                dict[batch['image_id'][0]] = image_feat

pickle.dump(dict, open(output_file, 'wb'))