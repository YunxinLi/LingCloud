# 使用CLIP提前抽取出特征并存储，加快 roberta+clip的训练速度
import json
import pickle

import torch
import clip
from PIL import Image
from torch.utils.data import Dataset
from tqdm import tqdm


DEVICE = 2
device = torch.device("cuda:{}".format(DEVICE))
from torch.utils.data import DataLoader

# def convert_models_to_fp32(model):
#     for name, p in model.named_parameters():
#         p.data = p.data.float()
#         p.grad.data = p.grad.data.float()


class ImageDatasetCoCo(Dataset):
    def __init__(self, data, preprocess):
        self.data = data
        self.preprocess = preprocess

    def __len__(self):
        return len(self.data)

    def __getitem__(self, i):
        example = self.data[i]
        text = example["caption"]
        id = example["id"]
        img_fn = example['img_fn']
        image_path = "../../coco_data/train2014/" + img_fn
        image = Image.open(image_path).convert('RGB')
        image = preprocess(image).to(device)
        img_id = example["image_id"]
        return {"image_id":img_id,
                "id":id,
                "image":image,
                "text":text}

    def gen_collate(self, inputs):
        image = [i['image'] for i in inputs]
        image_id = [i["image_id"] for i in inputs]
        text = [i["text"] for i in inputs]
        id = [i["id"] for i in inputs]
        image = torch.stack(image)
        text = clip.tokenize(text).to(device)

        return {"image_id":image_id,
                "id":id,
                "text":text,
                "image":image}


# extract_file1 = "../pmr_data/coco_data/train_caption.json"
extract_file1 = "../../coco_data/captions_train2014.json"
extract_file2 = "../../coco_data/captions_val2014.json"

output_file = "../../coco_data/img_feat/coco_img_large-fp32.pkl"
# output_file_text = "../pmr_data/clip_feat/clip_feat_coco_text_small.pkl"

print('ViT-L/14')
clip_model, preprocess = clip.load('ViT-L/14', device=device, jit=False)
clip.model.convert_weights(clip_model)

clip_model = clip_model.to(device)

# for name, param in clip_model.named_parameters():
#     if param.dtype != torch.float32:
#         param = param.float()

clip_model = clip_model.float()

# 使用dict存储特征
dict = {}
dict_text = {}

with open(extract_file1, 'r') as file:
    lines = file.readlines()
    ex_data1 = [json.loads(line) for line in lines]

with open(extract_file2, 'r') as file:
    lines = file.readlines()
    ex_data2 = [json.loads(line) for line in lines]
ex_data1 = ex_data1[0]['annotations']
ex_data2 = ex_data2[0]['annotations']

for data in ex_data1:
    data['image_id'] = str(data['image_id'])
    image_id = data['image_id']
    tmp = "COCO_train2014_" + "0" * (12-len(image_id)) + image_id + ".jpg"
    data["img_fn"] = tmp

for data in ex_data2:
    data['image_id'] = str(data['image_id'])
    image_id = data['image_id']
    tmp = "COCO_val2014_" + "0" * (12-len(image_id)) + image_id + ".jpg"
    data["img_fn"] = tmp

ex_data = ex_data2 + ex_data1

coco_dataset = ImageDatasetCoCo(ex_data, preprocess)
dataloader = DataLoader(coco_dataset, drop_last=False, batch_size=1,
                                num_workers=0,
                                shuffle=False, collate_fn=coco_dataset.gen_collate)

idx = 0

with torch.no_grad():
    with tqdm(total=len(dataloader)) as pbar:
        clip_model.eval()
        for step, batch in enumerate(dataloader):
            idx += 1
            pbar.update(1)
            # -----------image-------------
            if batch['image_id'][0] in dict:
                continue
            else:
                image = batch["image"]
                image_feat = clip_model.encode_image(image)
                # image_feat = image_feat.squeeze(dim=1)  # 仅仅是为了保持一致性
                image_feat = image_feat.cpu()

                assert batch['image_id'][0] not in dict
                dict[batch['image_id'][0]] = image_feat


pickle.dump(dict, open(output_file, 'wb'))


