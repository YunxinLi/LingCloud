import json

from PIL import Image

import clip
import os
import torch
import pickle
from tqdm import tqdm
from torch.utils.data import Dataset
from torch.utils.data import DataLoader

DEVICE = 0
device = torch.device("cuda:{}".format(DEVICE))


extract_file = "/raid/cxy/ReasoningTask/dataset/SemArt/semart_test.json"
output_file = "../../dataset/SemArt/img_feat_semart_test.pkl"
dict = {}
with open(extract_file, 'r') as file:
    lines = file.readlines()
    ex_data = [json.loads(line) for line in lines]


clip_model, preprocess = clip.load('ViT-L/14', jit=False, device=device)
clip.model.convert_weights(clip_model)

clip_model = clip_model.to(device)

class ImageDatasetCC3M(Dataset):
    def __init__(self, data, preprocess):
        self.data = data
        self.preprocess = preprocess

    def __len__(self):
        return len(self.data)

    def __getitem__(self, i):
        example = self.data[i]
        img_fn = example['image_id'] + ".jpg"
        image_path = "/raid/cxy/ReasoningTask/dataset/SemArt/Images/" + img_fn
        image = Image.open(image_path).convert('RGB')

        image = preprocess(image).to(device)
        img_id = example["image_id"]
        return {"image_id":img_id,
                "image":image,}

    def gen_collate(self, inputs):
        image = [i['image'] for i in inputs]
        image_id = [i["image_id"] for i in inputs]
        image = torch.stack(image)

        return {"image_id":image_id,
                "image":image}


cc3m_dataset = ImageDatasetCC3M(ex_data, preprocess)
dataloader = DataLoader(cc3m_dataset, drop_last=False, batch_size=128,
                        num_workers=0,
                        shuffle=False, collate_fn=cc3m_dataset.gen_collate)

with torch.no_grad():
    with tqdm(total=len(dataloader)) as pbar:
        clip_model.eval()
        for step, batch in enumerate(dataloader):
            pbar.update(1)
            # -----------image-------------

            image = batch["image"]
            image_feat = clip_model.encode_image(image)
            image_feat = image_feat.cpu()

            for idx in range(len(batch["image_id"])):
                t = image_feat[idx].unsqueeze(dim=0).cpu().numpy()
                dict[batch['image_id'][idx]] = t

pickle.dump(dict, open(output_file, 'wb'))


