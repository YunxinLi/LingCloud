import json

import clip
import torch
import pickle
from torch.utils.data import Dataset
from tqdm import tqdm
from PIL import Image
from torch.utils.data import DataLoader

DEVICE = 6
device = torch.device("cuda:{}".format(DEVICE))


# COCO_train2014_000000
class ImageDatasetnnNLVR(Dataset):
    def __init__(self, data, preprocess):
        self.data = data
        self.preprocess = preprocess

    def __len__(self):
        return len(self.data)

    def __getitem__(self, i):
        example = self.data[i]
        img_fn = example['image_id']
        image_path0 = "../../dataset/nlvr2/images/test2/" + img_fn + "-img0.png"
        image_path1 = "../../dataset/nlvr2/images/test2/" + img_fn + "-img1.png"
        image1 = Image.open(image_path0).convert('RGB')
        image2 = Image.open(image_path1).convert('RGB')

        image1 = preprocess(image1).to(device)
        image2 = preprocess(image2).to(device)
        img_id = example["image_id"]
        return {"image_id": img_id,
                "image1": image1,
                "image2": image2}

    def gen_collate(self, inputs):
        image1 = [i['image1'] for i in inputs]
        image2 = [i['image2'] for i in inputs]
        image_id = [i["image_id"] for i in inputs]

        # 假设batch_size = 1
        image = image1 + image2
        image = torch.stack(image)
        return {"image_id": image_id,
                "image": image}


clip_model, preprocess = clip.load('ViT-L/14', jit=False, device=device)
clip.model.convert_weights(clip_model)

clip_model = clip_model.to(device)

extract_file = "../../dataset/nlvr2/data/nlvr2_test2.json"
output_file = "../../dataset/nlvr2/data/img_feat_test2.pkl"

dict = {}
with open(extract_file, 'r') as file:
    lines = file.readlines()
    ex_data = [json.loads(line) for line in lines]

cc3m_dataset = ImageDatasetnnNLVR(ex_data, preprocess)
dataloader = DataLoader(cc3m_dataset, drop_last=False, batch_size=1,
                        num_workers=0,
                        shuffle=False, collate_fn=cc3m_dataset.gen_collate)

with torch.no_grad():
    with tqdm(total=len(dataloader)) as pbar:
        clip_model.eval()
        for step, batch in enumerate(dataloader):
            pbar.update(1)
            # -----------image-------------
            if batch['image_id'][0] in dict:
                continue
            else:
                image = batch["image"]
                image_feat = clip_model.encode_image(image)
                # image_feat = image_feat.squeeze(dim=1)  # 仅仅是为了保持一致性
                image_feat = image_feat.cpu()

                assert batch['image_id'][0] not in dict
                dict[batch['image_id'][0]] = image_feat

pickle.dump(dict, open(output_file, 'wb'))
