import json
import os
# os.environ['CUDA_VISIBLE_DEVICES'] = '6'
import clip
import torch
import pickle
from torch.utils.data import Dataset
from tqdm import tqdm
from PIL import Image
from torch.utils.data import DataLoader

DEVICE = 6
device = torch.device("cuda:{}".format(DEVICE))


# COCO_train2014_000000
class ImageDatasetCC3M(Dataset):
    def __init__(self, data, preprocess):
        self.data = data
        self.preprocess = preprocess
        self.image_id = []
        for line in data:
            if line["image_id"] not in self.image_id:
                self.image_id.append(line["image_id"])

    def __len__(self):
        return len(self.image_id)

    def __getitem__(self, i):
        example = self.image_id[i]
        image_path = "/data/share/dataset/MutilModalDataset/e-ViL/flickr30k_images/flickr30k_images/" + example + ".jpg"
        image = Image.open(image_path).convert('RGB')

        image = preprocess(image).to(device)
        return {"image_id": example,
                "image": image, }

    def gen_collate(self, inputs):
        image = [i['image'] for i in inputs]
        image_id = [i["image_id"] for i in inputs]
        image = torch.stack(image)

        return {"image_id": image_id,
                "image": image}


clip_model, preprocess = clip.load('ViT-L/14', jit=False, device=device)
clip.model.convert_weights(clip_model)

extract_file = "../../dataset/flickr30k/flickr30k.json"
output_file = "../../dataset/flickr30k/img_feat_flickr30k.pkl"

dict = {}
with open(extract_file, 'r') as file:
    lines = file.readlines()
    ex_data = [json.loads(line) for line in lines]

for data in ex_data:
    data["img_fn"] = data["image_id"] + ".jpg"

cc3m_dataset = ImageDatasetCC3M(ex_data, preprocess)
dataloader = DataLoader(cc3m_dataset, drop_last=False, batch_size=128,
                        num_workers=0,
                        shuffle=False, collate_fn=cc3m_dataset.gen_collate)

with torch.no_grad():
    with tqdm(total=len(dataloader)) as pbar:
        clip_model.eval()
        for step, batch in enumerate(dataloader):
            pbar.update(1)
            # -----------image-------------

            image = batch["image"]
            image_feat = clip_model.encode_image(image)
            image_feat = image_feat.cpu()

            for idx in range(len(batch["image_id"])):
                dict[batch['image_id'][idx]] = image_feat[idx]

pickle.dump(dict, open(output_file, 'wb'))
