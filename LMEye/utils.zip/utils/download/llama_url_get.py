base_url = "https://huggingface.co/decapoda-research/llama-7b-hf/resolve/main/pytorch_model-000"
late_url = "-of-00033.bin"

urls = []
for i in range(1, 34):
    url = base_url + "0" * (2-len(str(i))) + str(i) + late_url
    urls.append(url)

with open("llama_urls.txt", "w") as file:
    for line in urls:
        file.write(line + "\n")