import torch

a = torch.rand(1, 768)

b = 1