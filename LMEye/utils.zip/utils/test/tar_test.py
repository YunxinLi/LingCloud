#

import json

with open("/data/share/datasets/Laion-400m/processed/laion_0to120.json", "r") as file:
    lines = file.readlines()
    data = [json.loads(line) for line in lines]

a = 1