# import numpy as np
# import torch
# data = np.load("/data/share/datasets/Laion-400m/image_feat/000/000309091.npy")
#
# data = torch.from_numpy(data)
#
# b = 1

# import random
#
# # 创建一个包含数字0到32的列表
# numbers = list(range(33))
#
# # 遍历列表，为每个元素生成5个随机值，同时保证这些值不等于该元素本身
# for i in range(32):
#     temp = []
#     while len(temp) < 5:
#         rand_num = random.choice(numbers)
#         if rand_num != i and rand_num not in temp:
#             temp.append(rand_num)
#     # 将生成的5个随机数添加到当前元素的值列表中
#     numbers[i] = temp

# a = 1

import random

while 1:
    a = random.randint(0, 32)
    if a == 32:
        print(a)