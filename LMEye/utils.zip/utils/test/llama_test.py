import torch
from sentencepiece import SentencePieceProcessor
from transformers import GPT2Tokenizer
from local_transformers.transformers_new.models.llama.tokenization_llama import LlamaTokenizer
text = ["an apple", "he is a good man"]

sp_model = SentencePieceProcessor(model_file="../../local_transformers/llama-7b-hf/tokenizer.model")
print(sp_model.eos_id())

llm_tokenizer = LlamaTokenizer.from_pretrained("../../local_transformers/llama-7b-hf/", add_bos_token=False, add_eos_token=True)

gpt2_tokenizer = GPT2Tokenizer.from_pretrained("facebook/opt-1.3b")

x = llm_tokenizer(text, add_special_tokens=True, max_length=3, truncation=True)

def padding(inputs, max_length=50):
    input_ids = inputs["input_ids"]
    for idx in range(len(input_ids)):
        cur_l = len(input_ids[idx])
        if cur_l < max_length:
            inputs["input_ids"][idx] += [0] * (max_length - cur_l)
            inputs["attention_mask"][idx] += [0] * (max_length - cur_l)

    return torch.tensor(inputs["input_ids"]), torch.tensor(inputs["attention_mask"])

a,b = padding(x)
print(a.size(), b.size())
