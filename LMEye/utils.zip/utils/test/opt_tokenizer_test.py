import json
from tqdm import tqdm
from transformers import GPT2Tokenizer

opt_path = "local_transformers/opt-iml-max-1.3b/"
llm_tokenizer = GPT2Tokenizer.from_pretrained("facebook/opt-1.3b")

llm_tokenizer.add_special_tokens({"additional_special_tokens": ["<img>"]})
llm_tokenizer.add_special_tokens({"additional_special_tokens": ["<img-d>"]})

with open("../../dataset/instruction_data/instruction_test.json") as file:
    lines = file.readlines()
    data = [json.loads(line) for line in lines]

average_len = 0
max_len = 0
cnt200 = 0
cnt250 = 0
cnt300 = 0
with tqdm(total=len(data)) as pbar:
    for d in data:
        sent = llm_tokenizer(d["pre_sent"])["input_ids"]
        average_len += len(sent)
        max_len = max(max_len, len(sent))
        pbar.update(1)
    # if len(sent)>200:
    #     cnt200 +=1
    # if len(sent)>300:
    #     cnt300 +=1
    # if len(sent)>250:
    #     cnt250+=1

print(average_len/len(data))
print(max_len)
print(cnt200)
print(cnt250)
print(cnt300)


