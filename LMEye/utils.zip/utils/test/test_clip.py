a = (1,3)

x,y = a
print(x)