import random

# 初始化列表，填充-1表示还未记录过最小值的位置
min_list = [1000000] * 5

# 初始化位置列表，填充-1表示还未记录过最小值的位置
pos_list = [-1] * 5

total_list = []
# 进行一万次循环
for i in range(10000):
    # 计算结果
    result = random.randint(1, 100000)
    total_list.append(result)
    # 更新列表，保留最小的五个值及其位置
    if result < max(min_list):
        min_index = min_list.index(max(min_list))
        min_list[min_index] = result
        pos_list[min_index] = i
        # index_list = [i for i, x in enumerate(min_list) if x == result]
        # for index in index_list:
        #     if index != min_index:
        #         min_list[index] = -1
        #         pos_list[index] = -1

# 打印最小的五个值的位置
print(min_list)
print(pos_list)

total_list.sort()
print(total_list)