
# score_list = [[1000000] * 5] * 128
# pos_list = [[-1] * 5] * 128

score_list = []
pos_list = []
for i in range(128):
    a = [1000000] * 5
    b = [-1] * 5
    score_list.append(a)
    pos_list.append(b)

for i in range(0,100):
    scores = [i] * 128
    for idx, score in enumerate(scores):

        if score < max(score_list[idx]):
            min_index = score_list[idx].index(max(score_list[idx]))
            score_list[idx][min_index] = score
            pos_list[idx][min_index] = i