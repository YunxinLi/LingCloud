# a = [1,2,3]
import torch

a = torch.tensor([111])

if isinstance(a, torch.Tensor):
    a = 1